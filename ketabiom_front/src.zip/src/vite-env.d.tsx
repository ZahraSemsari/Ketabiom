/// <reference types="vite/client"/>
